import Head from 'next/head'
import Image from 'next/image'
import Challanges_section from '../src/challanges/Challanges_section'
import Companies from '../src/company/Companies'
import Customer_heading from '../src/customer/Customer_heading'
import Customer_section from '../src/customer/Customer_section'
import Hero_section from '../src/hero/Hero_section'
import Info_section from '../src/info/Info_section'
import Navigation_section from '../src/navbar/Navigation_section'
import Multiple_porducts_card from '../src/products/Multiple_porducts_card'
import Services_section from '../src/services/Services_section'
import styles from '../styles/Home.module.css'

export default function Home() {
  return (
    <div>
      <Navigation_section />
      <Hero_section />
      <Companies />
      <Services_section />
      <Challanges_section />
      <Multiple_porducts_card />
      <Customer_section />
      <Info_section />
    </div>
  )
}
