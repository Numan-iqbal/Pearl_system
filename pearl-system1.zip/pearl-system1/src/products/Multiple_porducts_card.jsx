import React from 'react'
import Products_card from './Products_card'

const Multiple_porducts_card = () => {
  return (
    <div className='flex flex-wrap gap-8 justify-center'>
        <Products_card />
        <Products_card />
        <Products_card />
        <Products_card />
        <Products_card />
        <Products_card />
    </div>
  )
}

export default Multiple_porducts_card