import Image from 'next/image'
import React from 'react'

const Products_card = () => {
  return (
    <div className=' max-w-sm text-center pt-16'>
      <div>
      <Image src={'/images/Rectangle1.png'} width={'346'} height={'207'} alt="Rectangle1.png" />
    </div>
    <p className=' pt-4 text-xl font-medium text-gray'>Cosmetic Forcest Marketing</p>
    </div>
  )
}

export default Products_card