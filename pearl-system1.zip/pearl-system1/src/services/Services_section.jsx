import React from 'react'
import Services_heading from './Services_heading'
import Services_icon from './Services_icon'

const Services_section = () => {
  return (
    <div className='flex'>
        <Services_heading />
        <Services_icon />
    </div>
  )
}

export default Services_section