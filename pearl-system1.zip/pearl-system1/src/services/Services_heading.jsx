import React from 'react'

const Services_heading = () => {
  return (
    <div>
        <p className=' text-base text-darkyellow font-bold pt-24'>SERVICES</p>
        <h2 className=' font-bold text-4xl text-gray pt-3'>Our Capabilities</h2>
        <p className=' text-light_gray font-normal text-xl max-w-[335px] pt-6'>We will bring the breathe of our experience and industry knowledge to help you succeed</p>
    </div>
  )
}

export default Services_heading