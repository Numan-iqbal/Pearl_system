import React from 'react'
import Card from './Card'

const Services_icon = () => {
  return (
    <div className='flex justify-center pt-36'>
        <Card />
        <Card />
        <Card />
    </div>
  )
}

export default Services_icon