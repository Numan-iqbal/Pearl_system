import Image from 'next/image'
import React from 'react'

const Card = () => {
  return (
    <div className=' max-w-300 w-72 px-12 pb-24'>
    <div>
        <Image src={'/images/cards.png'} width={'40'} height={'40'} alt='card icon' />
    </div>
    <p className=' pt-6 font-bold text-xl text-gray'>Market Forcest</p>
    <div className='pt-5 font-normal text-base text-light_gray'>
    <p>Leverage agile framework</p>
    <p>to provide a robust high</p>
    <p>level synopsys overviews</p>
    </div>
    </div>
    )
}

export default Card