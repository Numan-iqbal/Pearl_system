import React from 'react'

const Challanges_heading = () => {
  return (
    <div className=' pt-12 pb-16 max-w-495 pr-8'>
        <p className=' text-darkyellow font-normal text-base'>WHY CHOOSE US</p>
        <h2 className=' text-4xl font-bold text-white pt-3'>Take on any Challenge of the Digital World</h2>

        <div className=' text-dim_gray text-xl flex flex-col gap-5 pt-6'>
        <p>Corporate Financial Advisory</p>
        <p>Development of Financial Models</p>
        <p>Deal Structuring</p>
        <button className='w-52 h-14 mt-12 font-bold rounded-rounded-80 bg-light_pink text-white'>Get Started</button>
        </div>

    </div>
  )
}

export default Challanges_heading