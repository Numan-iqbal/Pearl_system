import Image from 'next/image'
import React from 'react'

const Challanges_icon = () => {
  return (
    <div>
        <Image src={'/images/challenges.png'} width={'656'} height={'552'} alt='challenges image' />
    </div>
  )
}

export default Challanges_icon