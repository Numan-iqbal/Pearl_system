import React from 'react'
import Challanges_heading from './Challanges_heading'
import Challanges_icon from './Challanges_icon'

const Challanges_section = () => {
  return (
    <div className=' bg-gray flex text-start'>
        <Challanges_icon />
        <Challanges_heading />
    </div>
  )
}

export default Challanges_section