import Image from 'next/image'
import React from 'react'

const Info_image = () => {
  return (
    <div>
        <Image src={'/images/Infoimg.png'} width={'584'} height={'643'} alt="Info_Image" />
    </div>
  )
}

export default Info_image