import React from "react";

const Info_form = () => {
  return (
    <div className=" max-w-539 pt-14">
      <p className="text-darkyellow font-normal text-base">CONTACT US</p>
      <h1 className=" text-4xl text-gray font-bold">Let’s Collaborate Now!</h1>

      <form action="#">
        <p className=" text-xl font-bold text-gray pt-10 pb-3">Full Name</p>
        <input type="text" placeholder="Input Your Name" className=" bg-pink-200 text-light_gray w-full h-14 rounded-3xl p-4 "/>
        <div className="flex">
        <div>
        <p className=" text-xl font-bold text-gray pt-9 pb-3">Email</p>
        <input type="email" name="Email" id="#" placeholder="Input Your Email" className=" bg-pink-200 text-light_gray max-w-250 h-14 rounded-3xl p-4 "/>
        </div>
        <span className=" px-3"></span>
        <div>
        <p className=" text-xl font-bold text-gray pt-9 pb-3">Date</p>
        <input type="email" name="Email" id="#" placeholder="Select Date" className=" bg-pink-200 text-light_gray max-w-250 h-14 rounded-3xl p-4 "/>
        </div>
        </div>
        <div className="">
        <p className=" text-xl font-bold text-gray pt-9 pb-3">Message</p>
        <input type="email" name="Email" id="#" placeholder="Write Message..." className=" bg-pink-200 text-light_gray w-full h-28 rounded-3xl p-5"/>
        </div>
      </form>
    </div>
  );
};

export default Info_form;
