import React from 'react'
import Info_form from './Info_form'
import Info_image from './Info_image'

const Info_section = () => {
  return (
    <div className='flex'>
        <Info_image />
        <Info_form />
    </div>
  )
}

export default Info_section