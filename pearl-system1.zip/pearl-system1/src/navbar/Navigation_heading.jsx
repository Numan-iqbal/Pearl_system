import React from 'react'

const Navigation_heading = () => {
  return (
    <div className=' flex gap-16 items-center text-base text-light_gray'>
  <a>Services</a>
  <a>Resources</a>
  <a>Company</a>
  <a>Blog</a>
  <a>Contact Us</a>

  <button className=' w-36 h-14 text-gray font-bold text-sm border-2 border-light_pink rounded-rounded-80'>Let’s Talk</button>
</div>
  )
}

export default Navigation_heading