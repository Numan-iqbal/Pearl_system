import Image from 'next/image'
import React from 'react'

export const Navigation_icon = () => {
  return (
    <div>
        <Image src={'/images/Icon.png'} height={'36'} width={'214'} alt='main icon' />
    </div>
  )
}
