import React from 'react'
import Navigation_heading from './Navigation_heading'
import { Navigation_icon } from './Navigation_icon'

const Navigation_section = () => {
  return (
    <div className='flex justify-between pt-10'>
        <Navigation_icon />
        <Navigation_heading />
    </div>
  )
}

export default Navigation_section