import Image from "next/image";
import React from "react";

const Customer_image = () => {
  return <div className="bg-[url('/images/map.png')]">
  </div>;
};

export default Customer_image;
