import React from 'react'

const Customer_heading = () => {
  return (
    <div className=' max-w-270 pt-8'>
        <p className=' text-darkyellow font-normal text-base'>TESTIMONIAL</p>
        <h2 className=' text-4xl text-gray font-bold pt-3'>What Our Customer’s Say</h2>
    </div>
  )
}

export default Customer_heading