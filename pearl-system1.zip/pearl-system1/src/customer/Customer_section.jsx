import React from 'react'
import Customer_heading from './Customer_heading'
import Customer_image from './Customer_image'

const Customer_section = () => {
  return (
    <div>
        <Customer_heading />
        <Customer_image />
    </div>
  )
}

export default Customer_section