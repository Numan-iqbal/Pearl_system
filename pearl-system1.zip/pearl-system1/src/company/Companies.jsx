import Image from 'next/image'
import React from 'react'

const Companies = () => {
  return (
    <div className=' flex justify-evenly pt-12'>
        <Image src={'/images/slack.png'} width={'200'} height={'80'} alt='company_image' />
        <Image src={'/images/prudential.png'} width={'200'} height={'80'} alt='company_image' />
        <Image src={'/images/microsoft.png'} width={'229'} height={'80'} alt='company_image' />
        <Image src={'/images/zoover.png'} width={'200'} height={'80'} alt='company_image' />
    </div>
  )
}

export default Companies