import React from 'react'
import { Hero_heading } from './Hero_heading'
import Hero_image from './Hero_image'

const Hero_section = () => {
  return (
    <div className=' flex items-center pt-3 justify-between'>
        <Hero_heading />
        <Hero_image />
    </div>
  )
}

export default Hero_section