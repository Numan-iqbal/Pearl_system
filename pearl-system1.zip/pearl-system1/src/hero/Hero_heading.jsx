import React from 'react'

export const Hero_heading = () => {
  return (
    <div className=''>
        <p className=' text-darkyellow'>Best Business Platform - World Record 2021</p>
        <div className=' text-gray font-bold text-5xl pt-5'>
        <h2>Reach Your Business</h2>
        <h2>Goals in Record Time</h2>
        </div>
        <p className=' text-light_gray font-normal text-xl pt-6 max-w-[561px]'>Support small business and join the nationwide movement to encourage commercial support for the millions of minority owned businesses helping world economy.</p>
        <button className='w-52 h-14 mt-16 font-bold rounded-rounded-80 bg-light_pink text-white'>Get Started</button>
        <span className=' px-1'></span>
        <button className='w-52 h-14 mt-16 rounded-rounded-80 bg-white text-black'>Watch Videos</button>
    </div>
  )
}
