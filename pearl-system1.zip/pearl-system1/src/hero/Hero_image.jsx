import Image from 'next/image'
import React from 'react'

const Hero_image = () => {
  return (
    <div>
        <Image src={'/images/hero_image.png'} width={'596'} height={'625'} alt='hero_image' />
    </div>
  )
}

export default Hero_image