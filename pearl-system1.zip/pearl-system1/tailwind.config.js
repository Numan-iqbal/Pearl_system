/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
      "./pages/**/*.{js,ts,jsx,tsx}",
      "./components/**/*.{js,ts,jsx,tsx}",
      "./src/**/*.{js,ts,jsx,tsx}",
    ],
  theme: {
    extend: {
      colors: {
       'gray': '#282C4B',
       'light_pink': '#FF698D',
       'light_gray': '#747582',
       'darkyellow' : '#F07922',
       'dim_gray': '#CED1E5',
      },
      borderRadius: {
        'rounded-80': '80px',
        
      },
      spacing: {
        'padding-70': '70px',
      },
      maxWidth: {
        '250': '250px',
        '177': '177px',
        '495': '495px',
        '270': '270px',
        '539': '539px',
      },
      backgroundImage: {
        'hero-pattern': "url('/images/map.png')",
      },
    },
  },
  plugins: [],
}
